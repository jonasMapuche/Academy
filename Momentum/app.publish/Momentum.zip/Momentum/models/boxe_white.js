"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoxeWhite = void 0;
class BoxeWhite {
    constructor(volts, coulomb, sequence) {
        this.volts = volts;
        this.coulomb = coulomb;
        this.sequence = sequence;
    }
}
exports.BoxeWhite = BoxeWhite;
//# sourceMappingURL=boxe_white.js.map
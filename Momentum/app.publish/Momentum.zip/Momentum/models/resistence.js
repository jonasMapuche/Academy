"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Resistence = void 0;
class Resistence {
}
exports.Resistence = Resistence;
//# sourceMappingURL=resistence.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Momentum = void 0;
class Momentum {
    constructor(name, malware) {
        this.name = name;
        this.malware = malware;
    }
}
exports.Momentum = Momentum;
//# sourceMappingURL=momentum.js.map